<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class NjangiContribution extends Model
{
    protected $fillable = [
        'organization_id',
        'njangi_cycle_id',
        'njangi_session_id',
        'contributor_member_id',
        'beneficiary_member_id',
        'payment_submission_id',
        'amount',
        'payment_date',
        'payment_method',
        'reference_number',
        'notes',
    ];

    protected $casts = [
        'amount' => 'decimal:2',
        'payment_date' => 'date',
    ];

    public function organization(): BelongsTo
    {
        return $this->belongsTo(Organization::class);
    }

    public function cycle(): BelongsTo
    {
        return $this->belongsTo(NjangiCycle::class, 'njangi_cycle_id');
    }

    public function session(): BelongsTo
    {
        return $this->belongsTo(NjangiSession::class, 'njangi_session_id');
    }

    public function contributor(): BelongsTo
    {
        return $this->belongsTo(Member::class, 'contributor_member_id');
    }

    public function beneficiary(): BelongsTo
    {
        return $this->belongsTo(Member::class, 'beneficiary_member_id');
    }

    public function paymentSubmission(): BelongsTo
    {
        return $this->belongsTo(NjangiPaymentSubmission::class, 'payment_submission_id');
    }
}